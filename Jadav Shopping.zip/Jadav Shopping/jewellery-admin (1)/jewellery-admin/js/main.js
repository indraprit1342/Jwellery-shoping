// Main Admin Panel JavaScript
class AdminPanel {
    constructor() {
        this.init();
    }

    init() {
        this.initializeSidebar();
        this.initializeEventListeners();
        this.initializeNotifications();
        this.checkMobileView();
        this.loadUserPreferences();
    }

    // Sidebar functionality
    initializeSidebar() {
        this.sidebar = document.getElementById('sidebar');
        this.mobileMenuBtn = document.getElementById('mobileMenuBtn');
        
        // Create mobile menu button if it doesn't exist
        if (!this.mobileMenuBtn && this.sidebar) {
            this.mobileMenuBtn = document.createElement('button');
            this.mobileMenuBtn.id = 'mobileMenuBtn';
            this.mobileMenuBtn.className = 'mobile-menu-btn d-md-none';
            this.mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            this.mobileMenuBtn.onclick = () => this.toggleSidebar();
            document.body.appendChild(this.mobileMenuBtn);
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && this.sidebar && this.sidebar.classList.contains('active')) {
                if (!this.sidebar.contains(e.target) && e.target !== this.mobileMenuBtn) {
                    this.closeSidebar();
                }
            }
        });
    }

    toggleSidebar() {
        if (this.sidebar) {
            this.sidebar.classList.toggle('active');
        }
    }

    closeSidebar() {
        if (this.sidebar) {
            this.sidebar.classList.remove('active');
        }
    }

    // Event listeners
    initializeEventListeners() {
        // Search functionality
        const searchInputs = document.querySelectorAll('input[type="text"][id*="search"], input[type="text"][id*="Search"]');
        searchInputs.forEach(input => {
            input.addEventListener('input', (e) => {
                this.debounce(() => {
                    this.searchTable(e.target.value, e.target.id);
                }, 300)();
            });
        });

        // Form submissions
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                if (this.validateForm(form.id)) {
                    this.handleFormSubmit(form);
                }
            });
        });

        // Image previews
        const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]');
        imageInputs.forEach(input => {
            input.addEventListener('change', (e) => {
                this.previewImage(e.target);
            });
        });

        // Export buttons
        const exportButtons = document.querySelectorAll('[onclick*="export"]');
        exportButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const onclick = button.getAttribute('onclick');
                if (onclick.includes('exportToCSV')) {
                    const match = onclick.match(/exportToCSV\('([^']+)',\s*'([^']+)'\)/);
                    if (match) {
                        this.exportToCSV(match[1], match[2]);
                    }
                }
            });
        });
    }

    // Notification system
    initializeNotifications() {
        this.notificationContainer = document.createElement('div');
        this.notificationContainer.id = 'notificationContainer';
        this.notificationContainer.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        `;
        document.body.appendChild(this.notificationContainer);
    }

    showNotification(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show`;
        notification.style.cssText = 'min-width: 300px; margin-bottom: 10px;';
        notification.innerHTML = `
            ${this.getNotificationIcon(type)} ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        this.notificationContainer.appendChild(notification);
        
        // Auto remove after duration
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);
        
        return notification;
    }

    getNotificationIcon(type) {
        const icons = {
            success: '<i class="fas fa-check-circle me-2"></i>',
            error: '<i class="fas fa-exclamation-circle me-2"></i>',
            warning: '<i class="fas fa-exclamation-triangle me-2"></i>',
            info: '<i class="fas fa-info-circle me-2"></i>'
        };
        return icons[type] || icons.info;
    }

    // Search functionality
    searchTable(searchTerm, tableId) {
        const table = document.getElementById(tableId.replace('search', 'Table').replace('Search', 'Table'));
        if (!table) return;

        const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
        searchTerm = searchTerm.toLowerCase();

        for (let i = 0; i < rows.length; i++) {
            const cells = rows[i].getElementsByTagName('td');
            let found = false;
            
            for (let j = 0; j < cells.length; j++) {
                const cellText = cells[j].textContent || cells[j].innerText;
                if (cellText.toLowerCase().indexOf(searchTerm) > -1) {
                    found = true;
                    break;
                }
            }
            
            rows[i].style.display = found ? '' : 'none';
        }
    }

    // Form validation
    validateForm(formId) {
        const form = document.getElementById(formId);
        if (!form) return true;

        const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
        let isValid = true;

        inputs.forEach(input => {
            if (!input.value.trim()) {
                input.classList.add('is-invalid');
                isValid = false;
            } else {
                input.classList.remove('is-invalid');
                
                // Additional validation for specific input types
                if (input.type === 'email' && !this.isValidEmail(input.value)) {
                    input.classList.add('is-invalid');
                    isValid = false;
                }
                
                if (input.type === 'tel' && !this.isValidPhone(input.value)) {
                    input.classList.add('is-invalid');
                    isValid = false;
                }
            }
        });

        if (!isValid) {
            this.showNotification('Please fill all required fields correctly.', 'warning');
        }

        return isValid;
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    isValidPhone(phone) {
        const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
        return phoneRegex.test(phone);
    }

    // Form submission handler
    handleFormSubmit(form) {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        // Show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
        submitBtn.disabled = true;

        // Simulate API call
        setTimeout(() => {
            this.showNotification('Form submitted successfully!', 'success');
            form.reset();
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            
            // Close modal if form is in modal
            const modal = form.closest('.modal');
            if (modal) {
                const bsModal = bootstrap.Modal.getInstance(modal);
                if (bsModal) {
                    bsModal.hide();
                }
            }
        }, 1500);
    }

    // Image preview
    previewImage(input) {
        const file = input.files[0];
        if (!file) return;

        const previewId = input.id + 'Preview';
        let preview = document.getElementById(previewId);
        
        if (!preview) {
            preview = document.createElement('img');
            preview.id = previewId;
            preview.style.maxWidth = '200px';
            preview.style.maxHeight = '200px';
            preview.style.display = 'none';
            preview.className = 'mt-2 rounded';
            input.parentNode.appendChild(preview);
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }

    // Export to CSV
    exportToCSV(tableId, filename = 'data') {
        const table = document.getElementById(tableId);
        if (!table) {
            this.showNotification('Table not found for export.', 'error');
            return;
        }

        let csv = [];
        const rows = table.querySelectorAll('tr');

        for (let i = 0; i < rows.length; i++) {
            const row = [], cols = rows[i].querySelectorAll('td, th');
            
            for (let j = 0; j < cols.length; j++) {
                // Skip action columns
                if (cols[j].querySelector('button, .btn')) continue;
                
                let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/(\s\s)/gm, " ");
                data = data.replace(/"/g, '""');
                row.push('"' + data + '"');
            }
            
            csv.push(row.join(','));
        }

        const csvString = csv.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        
        link.setAttribute('hidden', '');
        link.setAttribute('href', url);
        link.setAttribute('download', `${filename}-${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        this.showNotification('Data exported successfully!', 'success');
    }

    // Utility functions
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    checkMobileView() {
        if (window.innerWidth <= 768) {
            document.body.classList.add('mobile-view');
        } else {
            document.body.classList.remove('mobile-view');
            this.closeSidebar();
        }
    }

    loadUserPreferences() {
        // Load theme preference
        const theme = localStorage.getItem('adminTheme') || 'light';
        document.body.setAttribute('data-theme', theme);
        
        // Load sidebar state
        const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        if (sidebarCollapsed && window.innerWidth > 768) {
            this.closeSidebar();
        }
    }

    saveUserPreferences() {
        localStorage.setItem('sidebarCollapsed', this.sidebar?.classList.contains('active') ? 'false' : 'true');
    }

    // Data management helpers
    generateId(prefix = 'item') {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    formatCurrency(amount, currency = '₹') {
        return `${currency}${amount.toLocaleString('en-IN')}`;
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    // API simulation (for demo purposes)
    async simulateAPIcall(endpoint, data = {}, method = 'GET') {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    success: true,
                    data: data,
                    message: `${method} request to ${endpoint} successful`
                });
            }, 1000 + Math.random() * 1000);
        });
    }
}

// Global functions for HTML onclick attributes
function showNotification(message, type = 'info') {
    if (window.adminPanel) {
        window.adminPanel.showNotification(message, type);
    }
}

function searchTable() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput && window.adminPanel) {
        window.adminPanel.searchTable(searchInput.value, 'dataTable');
    }
}

function validateForm(formId) {
    return window.adminPanel ? window.adminPanel.validateForm(formId) : false;
}

function previewImage(input, previewId) {
    if (window.adminPanel) {
        window.adminPanel.previewImage(input, previewId);
    }
}

function exportToCSV(tableId, filename) {
    if (window.adminPanel) {
        window.adminPanel.exportToCSV(tableId, filename);
    }
}

function toggleSidebar() {
    if (window.adminPanel) {
        window.adminPanel.toggleSidebar();
    }
}

// Initialize admin panel when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.adminPanel = new AdminPanel();
    
    // Initialize Bootstrap components
    if (typeof bootstrap !== 'undefined') {
        // Tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Popovers
        const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });
    }

    // Add resize listener
    window.addEventListener('resize', function() {
        if (window.adminPanel) {
            window.adminPanel.checkMobileView();
        }
    });

    // Add beforeunload listener to save preferences
    window.addEventListener('beforeunload', function() {
        if (window.adminPanel) {
            window.adminPanel.saveUserPreferences();
        }
    });
});

// Sample data and functions for demo purposes
const sampleData = {
    products: [
        { id: 1, name: 'Diamond Ring', category: 'Rings', price: 25000, stock: 15, status: 'In Stock' },
        { id: 2, name: 'Gold Necklace', category: 'Necklaces', price: 18500, stock: 8, status: 'Low Stock' },
        { id: 3, name: 'Pearl Earrings', category: 'Earrings', price: 9800, stock: 0, status: 'Out of Stock' }
    ],
    orders: [
        { id: 1, customer: 'Rahul Sharma', date: '2024-01-15', amount: 12500, status: 'Delivered' },
        { id: 2, customer: 'Priya Patel', date: '2024-01-14', amount: 8300, status: 'Pending' },
        { id: 3, customer: 'Amit Kumar', date: '2024-01-14', amount: 15200, status: 'Shipped' }
    ],
    customers: [
        { id: 1, name: 'Rahul Sharma', email: 'rahul@email.com', orders: 12, spent: 125000, type: 'VIP' },
        { id: 2, name: 'Priya Patel', email: 'priya@email.com', orders: 8, spent: 68500, type: 'Regular' },
        { id: 3, name: 'Amit Kumar', email: 'amit@email.com', orders: 3, spent: 32000, type: 'New' }
    ]
};

// Demo functions for various actions
function addProduct() {
    showNotification('Product added successfully!', 'success');
}

function editProduct(id) {
    showNotification(`Editing product ID: ${id}`, 'info');
}

function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product?')) {
        showNotification('Product deleted successfully!', 'success');
    }
}

function updateOrderStatus(orderId, status) {
    showNotification(`Order #${orderId} status updated to: ${status}`, 'success');
}

function viewOrderDetails(orderId) {
    showNotification(`Viewing order details for #${orderId}`, 'info');
}

function addCustomer() {
    showNotification('Customer added successfully!', 'success');
}

function updateBanner() {
    showNotification('Homepage banner updated successfully!', 'success');
}

function addPost() {
    showNotification('Blog post published successfully!', 'success');
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('Error occurred:', e.error);
    if (window.adminPanel) {
        window.adminPanel.showNotification('An error occurred. Please try again.', 'error');
    }
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AdminPanel, sampleData };
}