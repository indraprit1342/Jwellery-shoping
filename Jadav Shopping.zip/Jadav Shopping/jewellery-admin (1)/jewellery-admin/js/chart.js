// Chart colors configuration
const chartColors = {
    primary: '#4e73df',
    success: '#1cc88a',
    info: '#36b9cc',
    warning: '#f6c23e',
    danger: '#e74a3b',
    secondary: '#858796',
    dark: '#5a5c69',
    light: '#f8f9fa'
};

// Initialize all charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
});

// Main charts initialization function
function initializeCharts() {
    // Sales/Revenue Chart
    initSalesChart();
    
    // Category Distribution Chart
    initCategoryChart();
    
    // Monthly Orders Chart (if exists)
    initOrdersChart();
    
    // Customer Growth Chart (if exists)
    initCustomerChart();
}

// Sales Revenue Chart
function initSalesChart() {
    const salesCtx = document.getElementById('salesChart');
    if (!salesCtx) return;
    
    const salesChart = new Chart(salesCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue (₹)',
                data: [85000, 92000, 78000, 110000, 125000, 145000, 132000, 156000, 142000, 168000, 189000, 245000],
                borderColor: chartColors.primary,
                backgroundColor: 'rgba(78, 115, 223, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: chartColors.primary,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: chartColors.dark,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: chartColors.primary,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `Revenue: ₹${context.parsed.y.toLocaleString('en-IN')}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        color: chartColors.dark
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        color: chartColors.dark,
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'nearest'
            },
            animation: {
                duration: 1000,
                easing: 'easeOutQuart'
            }
        }
    });
}

// Product Categories Chart
function initCategoryChart() {
    const categoryCtx = document.getElementById('categoryChart');
    if (!categoryCtx) return;
    
    const categoryChart = new Chart(categoryCtx, {
        type: 'doughnut',
        data: {
            labels: ['Rings', 'Necklaces', 'Earrings', 'Bracelets', 'Others'],
            datasets: [{
                data: [35, 25, 20, 15, 5],
                backgroundColor: [
                    chartColors.primary,
                    chartColors.success,
                    chartColors.info,
                    chartColors.warning,
                    chartColors.secondary
                ],
                hoverBackgroundColor: [
                    '#2e59d9',
                    '#17a673',
                    '#2c9faf',
                    '#dda20a',
                    '#656776'
                ],
                hoverBorderColor: "rgba(234, 236, 244, 1)",
                borderWidth: 2,
                hoverOffset: 8
            }],
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: chartColors.primary,
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value}% (${percentage}% of total)`;
                        }
                    }
                }
            },
            cutout: '70%',
            animation: {
                animateScale: true,
                animateRotate: true,
                duration: 1000,
                easing: 'easeOutQuart'
            }
        },
    });
}

// Monthly Orders Chart
function initOrdersChart() {
    const ordersCtx = document.getElementById('ordersChart');
    if (!ordersCtx) return;
    
    const ordersChart = new Chart(ordersCtx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Orders',
                data: [45, 52, 38, 65, 72, 85, 78, 92, 88, 95, 102, 125],
                backgroundColor: chartColors.info,
                borderColor: chartColors.info,
                borderWidth: 1,
                borderRadius: 4,
                borderSkipped: false,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                }
            }
        }
    });
}

// Customer Growth Chart
function initCustomerChart() {
    const customerCtx = document.getElementById('customerChart');
    if (!customerCtx) return;
    
    const customerChart = new Chart(customerCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'New Customers',
                data: [25, 30, 28, 45, 50, 65, 58, 72, 68, 80, 85, 95],
                borderColor: chartColors.success,
                backgroundColor: 'rgba(28, 200, 138, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                }
            }
        }
    });
}

// Update chart data dynamically
function updateChartData(chartId, newData) {
    const chart = Chart.getChart(chartId);
    if (chart) {
        chart.data.datasets[0].data = newData;
        chart.update();
    }
}

// Add random data to chart (for demo purposes)
function addRandomData(chartId) {
    const chart = Chart.getChart(chartId);
    if (chart) {
        const newData = chart.data.datasets[0].data.map(value => {
            const change = Math.random() * 20 - 10; // Random change between -10 and +10
            return Math.max(0, Math.round(value + change));
        });
        
        chart.data.datasets[0].data = newData;
        chart.update('active');
        
        showNotification('Chart data updated with random values', 'info');
    }
}

// Export chart as image
function exportChartAsImage(chartId, filename = 'chart') {
    const chart = Chart.getChart(chartId);
    if (chart) {
        const image = chart.toBase64Image();
        const link = document.createElement('a');
        link.href = image;
        link.download = `${filename}-${new Date().toISOString().split('T')[0]}.png`;
        link.click();
        showNotification('Chart exported successfully!', 'success');
    }
}

// Reset chart to original data
function resetChart(chartId, originalData) {
    const chart = Chart.getChart(chartId);
    if (chart && originalData) {
        chart.data.datasets[0].data = [...originalData];
        chart.update();
        showNotification('Chart data reset to original', 'info');
    }
}

// Chart responsive helper
function makeChartResponsive() {
    const charts = Chart.instances;
    charts.forEach(chart => {
        chart.resize();
    });
}

// Listen for window resize to adjust charts
window.addEventListener('resize', function() {
    setTimeout(makeChartResponsive, 100);
});

// Initialize charts when tab becomes visible
document.addEventListener('visibilitychange', function() {
    if (!document.hidden) {
        setTimeout(initializeCharts, 100);
    }
});